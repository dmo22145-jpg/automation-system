import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { campaigns, processedComments, config } from '@/db/schema';
import { eq, and } from 'drizzle-orm';
import { InstagramApiClient, withRetry } from '@/lib/instagram';

/**
 * Webhook verification (GET request from Facebook)
 * When setting up the webhook, Facebook will send a GET request with hub.mode, hub.verify_token, and hub.challenge
 */
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const mode = searchParams.get('hub.mode');
  const token = searchParams.get('hub.verify_token');
  const challenge = searchParams.get('hub.challenge');

  const verifyToken = process.env.WEBHOOK_VERIFY_TOKEN;

  if (mode === 'subscribe' && token === verifyToken) {
    console.log('Webhook verified successfully');
    return new NextResponse(challenge, { status: 200 });
  }

  console.error('Webhook verification failed');
  return NextResponse.json({ error: 'Verification failed' }, { status: 403 });
}

/**
 * Webhook event handler (POST request from Facebook)
 * Receives Instagram comment notifications
 */
export async function POST(request: NextRequest) {
  try {
    // Get raw body for signature verification
    const rawBody = await request.text();
    const signature = request.headers.get('x-hub-signature-256');
    
    // Verify webhook signature
    const appSecret = process.env.FACEBOOK_APP_SECRET;
    if (appSecret && signature) {
      const isValid = InstagramApiClient.verifyWebhookSignature(
        signature,
        rawBody,
        appSecret
      );
      
      if (!isValid) {
        console.error('Invalid webhook signature');
        return NextResponse.json({ error: 'Invalid signature' }, { status: 403 });
      }
    }

    const body = JSON.parse(rawBody);
    
    console.log('Webhook received:', JSON.stringify(body, null, 2));

    // Process each entry
    for (const entry of body.entry || []) {
      for (const change of entry.changes || []) {
        if (change.field === 'comments') {
          await handleCommentEvent(change.value);
        }
      }
    }

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    console.error('Webhook processing error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * Handle a comment event from Instagram
 */
async function handleCommentEvent(value: any) {
  const commentId = value.id;
  const commentText = value.text || '';
  const mediaId = value.media?.id;

  if (!commentId || !mediaId) {
    console.log('Missing comment ID or media ID, skipping');
    return;
  }

  // Check if we've already processed this comment
  const existing = await db
    .select()
    .from(processedComments)
    .where(eq(processedComments.commentId, commentId))
    .limit(1);

  if (existing.length > 0) {
    console.log(`Comment ${commentId} already processed, skipping`);
    return;
  }

  // Find matching active campaigns for this post
  const activeCampaigns = await db
    .select()
    .from(campaigns)
    .where(and(
      eq(campaigns.postId, mediaId),
      eq(campaigns.isActive, true)
    ));

  if (activeCampaigns.length === 0) {
    console.log(`No active campaigns for post ${mediaId}`);
    return;
  }

  // Check if comment matches any campaign keywords
  for (const campaign of activeCampaigns) {
    const keywords = campaign.keywords.split(',').map(k => k.trim().toLowerCase());
    const matchesKeyword = keywords.some(keyword => 
      commentText.toLowerCase().includes(keyword)
    );

    if (matchesKeyword) {
      console.log(`Comment matches campaign ${campaign.id} with keywords: ${campaign.keywords}`);
      await processCampaignMatch(campaign, commentId, value);
      break; // Only process the first matching campaign
    }
  }
}

/**
 * Process a comment that matches a campaign
 */
async function processCampaignMatch(campaign: any, commentId: string, commentData: any) {
  try {
    // Get Instagram credentials
    const configData = await db.select().from(config).limit(1);
    if (configData.length === 0 || !configData[0].instagramAccessToken) {
      console.error('Instagram credentials not configured');
      return;
    }

    const apiClient = new InstagramApiClient(configData[0].instagramAccessToken!);

    // Get comment details to retrieve commenter's Instagram user ID
    const commentDetails = await apiClient.getCommentDetails(commentId);
    const commenterUserId = commentDetails.from.id;
    const commenterUsername = commentDetails.from.username;

    // Reply to the comment
    console.log(`Replying to comment ${commentId}...`);
    await withRetry(() => apiClient.replyToComment(commentId, campaign.commentReply));
    console.log('Comment reply sent successfully');

    // Send DM to the commenter
    try {
      console.log(`Sending DM to user ${commenterUserId}...`);
      await withRetry(() => apiClient.sendDm(commenterUserId, campaign.dmMessage));
      console.log('DM sent successfully');
    } catch (dmError) {
      // DM might fail if user hasn't messaged the business first
      // Log the error but don't fail the entire process
      console.error('Failed to send DM (this is expected if user hasn\'t messaged first):', dmError);
    }

    // Mark comment as processed
    await db.insert(processedComments).values({
      commentId,
      campaignId: campaign.id,
      commenterUsername,
      processedAt: new Date(),
    });

    console.log(`Successfully processed comment ${commentId}`);
  } catch (error) {
    console.error(`Error processing campaign match for comment ${commentId}:`, error);
    throw error;
  }
}
