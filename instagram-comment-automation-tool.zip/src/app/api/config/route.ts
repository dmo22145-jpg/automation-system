import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { config } from '@/db/schema';

/**
 * GET /api/config - Retrieve current configuration
 */
export async function GET() {
  try {
    const configData = await db.select().from(config).limit(1);
    
    if (configData.length === 0) {
      // Return empty config if none exists
      return NextResponse.json({
        instagramAccessToken: '',
        instagramBusinessAccountId: '',
        pageId: '',
        webhookVerifyToken: '',
        facebookAppSecret: '',
      });
    }

    // Don't expose full secrets to the frontend
    return NextResponse.json({
      instagramAccessToken: configData[0].instagramAccessToken ? '••••••••' : '',
      instagramBusinessAccountId: configData[0].instagramBusinessAccountId || '',
      pageId: configData[0].pageId || '',
      webhookVerifyToken: configData[0].webhookVerifyToken ? '••••••••' : '',
      facebookAppSecret: configData[0].facebookAppSecret ? '••••••••' : '',
      hasConfig: !!(configData[0].instagramAccessToken && configData[0].instagramBusinessAccountId),
    });
  } catch (error) {
    console.error('Error fetching config:', error);
    return NextResponse.json(
      { error: 'Failed to fetch configuration' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/config - Update configuration
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      instagramAccessToken,
      instagramBusinessAccountId,
      pageId,
      webhookVerifyToken,
      facebookAppSecret,
    } = body;

    // Check if config exists
    const existing = await db.select().from(config).limit(1);

    const configData = {
      instagramAccessToken: instagramAccessToken || undefined,
      instagramBusinessAccountId: instagramBusinessAccountId || undefined,
      pageId: pageId || undefined,
      webhookVerifyToken: webhookVerifyToken || undefined,
      facebookAppSecret: facebookAppSecret || undefined,
      updatedAt: new Date(),
    };

    if (existing.length === 0) {
      // Insert new config
      await db.insert(config).values(configData);
    } else {
      // Update existing config
      await db.update(config).set(configData).where(eq(config.id, existing[0].id));
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error updating config:', error);
    return NextResponse.json(
      { error: 'Failed to update configuration' },
      { status: 500 }
    );
  }
}

// Import eq for update query
import { eq } from 'drizzle-orm';
