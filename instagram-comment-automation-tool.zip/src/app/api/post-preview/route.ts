import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { config } from '@/db/schema';
import { InstagramApiClient } from '@/lib/instagram';

/**
 * GET /api/post-preview?postId=xxx - Get Instagram post details for preview
 */
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const postId = searchParams.get('postId');

    if (!postId) {
      return NextResponse.json(
        { error: 'Missing postId parameter' },
        { status: 400 }
      );
    }

    // Get Instagram credentials
    const configData = await db.select().from(config).limit(1);
    if (configData.length === 0 || !configData[0].instagramAccessToken) {
      return NextResponse.json(
        { error: 'Instagram credentials not configured' },
        { status: 400 }
      );
    }

    const apiClient = new InstagramApiClient(configData[0].instagramAccessToken);
    const postDetails = await apiClient.getPostDetails(postId);

    return NextResponse.json({
      id: postDetails.id,
      caption: postDetails.caption || '',
      mediaType: postDetails.media_type,
      thumbnail: postDetails.thumbnail_url || postDetails.media_url || '',
      permalink: postDetails.permalink,
    });
  } catch (error: any) {
    console.error('Error fetching post preview:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to fetch post details' },
      { status: 500 }
    );
  }
}
