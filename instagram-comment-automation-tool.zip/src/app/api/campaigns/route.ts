import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { campaigns, config } from '@/db/schema';
import { desc } from 'drizzle-orm';
import { InstagramApiClient } from '@/lib/instagram';

/**
 * GET /api/campaigns - List all campaigns
 */
export async function GET() {
  try {
    const allCampaigns = await db
      .select()
      .from(campaigns)
      .orderBy(desc(campaigns.createdAt));

    return NextResponse.json(allCampaigns);
  } catch (error) {
    console.error('Error fetching campaigns:', error);
    return NextResponse.json(
      { error: 'Failed to fetch campaigns' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/campaigns - Create a new campaign
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      postId,
      keywords,
      commentReply,
      dmMessage,
      isActive = true,
    } = body;

    // Validate required fields
    if (!postId || !keywords || !commentReply || !dmMessage) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Fetch post details from Instagram
    let postThumbnail = null;
    let postCaption = null;

    try {
      const configData = await db.select().from(config).limit(1);
      if (configData.length > 0 && configData[0].instagramAccessToken) {
        const apiClient = new InstagramApiClient(configData[0].instagramAccessToken);
        const postDetails = await apiClient.getPostDetails(postId);
        postThumbnail = postDetails.thumbnail_url || postDetails.media_url || null;
        postCaption = postDetails.caption || null;
      }
    } catch (error) {
      console.error('Failed to fetch post details:', error);
      // Continue anyway, just without thumbnail/caption
    }

    // Insert campaign
    const [newCampaign] = await db
      .insert(campaigns)
      .values({
        postId,
        postThumbnail,
        postCaption,
        keywords,
        commentReply,
        dmMessage,
        isActive,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();

    return NextResponse.json(newCampaign, { status: 201 });
  } catch (error) {
    console.error('Error creating campaign:', error);
    return NextResponse.json(
      { error: 'Failed to create campaign' },
      { status: 500 }
    );
  }
}
