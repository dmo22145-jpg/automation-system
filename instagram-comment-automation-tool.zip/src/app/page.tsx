'use client';

import { useState, useEffect } from 'react';
import ConfigPanel from '@/components/ConfigPanel';
import CampaignsList from '@/components/CampaignsList';
import CampaignForm from '@/components/CampaignForm';

export default function Home() {
  const [activeTab, setActiveTab] = useState<'settings' | 'campaigns'>('campaigns');
  const [showCampaignForm, setShowCampaignForm] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState<any>(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const handleCampaignSaved = () => {
    setShowCampaignForm(false);
    setEditingCampaign(null);
    setRefreshTrigger(prev => prev + 1);
  };

  const handleEditCampaign = (campaign: any) => {
    setEditingCampaign(campaign);
    setShowCampaignForm(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            📸 Instagram Automation Dashboard
          </h1>
          <p className="text-purple-200">
            Automate comment replies and DMs based on keywords
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-6 border-b border-purple-500/30">
          <button
            onClick={() => setActiveTab('campaigns')}
            className={`px-6 py-3 font-medium transition-all ${
              activeTab === 'campaigns'
                ? 'text-white border-b-2 border-purple-400'
                : 'text-purple-300 hover:text-white'
            }`}
          >
            🎯 Campaigns
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-6 py-3 font-medium transition-all ${
              activeTab === 'settings'
                ? 'text-white border-b-2 border-purple-400'
                : 'text-purple-300 hover:text-white'
            }`}
          >
            ⚙️ Settings
          </button>
        </div>

        {/* Content */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-8">
          {activeTab === 'settings' && <ConfigPanel />}
          
          {activeTab === 'campaigns' && (
            <>
              {!showCampaignForm ? (
                <>
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold text-white">
                      Active Campaigns
                    </h2>
                    <button
                      onClick={() => {
                        setEditingCampaign(null);
                        setShowCampaignForm(true);
                      }}
                      className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors shadow-lg hover:shadow-purple-500/50"
                    >
                      + New Campaign
                    </button>
                  </div>
                  <CampaignsList
                    refreshTrigger={refreshTrigger}
                    onEdit={handleEditCampaign}
                    onDeleted={() => setRefreshTrigger(prev => prev + 1)}
                  />
                </>
              ) : (
                <CampaignForm
                  campaign={editingCampaign}
                  onSaved={handleCampaignSaved}
                  onCancel={() => {
                    setShowCampaignForm(false);
                    setEditingCampaign(null);
                  }}
                />
              )}
            </>
          )}
        </div>

        {/* Footer Info */}
        <div className="mt-8 text-center text-purple-300 text-sm">
          <p>
            Webhook URL: <code className="bg-black/30 px-2 py-1 rounded">{typeof window !== 'undefined' ? window.location.origin : ''}/api/webhook/instagram</code>
          </p>
          <p className="mt-2">
            Make sure to configure your Facebook App webhook to point to this URL
          </p>
        </div>
      </div>
    </div>
  );
}
