/**
 * Instagram Graph API Client
 * Official API documentation: https://developers.facebook.com/docs/instagram-api
 */

const GRAPH_API_VERSION = 'v21.0';
const GRAPH_API_BASE = `https://graph.facebook.com/${GRAPH_API_VERSION}`;

interface InstagramApiError {
  error: {
    message: string;
    type: string;
    code: number;
  };
}

export class InstagramApiClient {
  private accessToken: string;

  constructor(accessToken: string) {
    this.accessToken = accessToken;
  }

  /**
   * Reply to an Instagram comment
   * @param commentId The Instagram comment ID
   * @param message The reply text
   */
  async replyToComment(commentId: string, message: string): Promise<{ id: string }> {
    const url = `${GRAPH_API_BASE}/${commentId}/replies`;
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        access_token: this.accessToken,
      }),
    });

    if (!response.ok) {
      const error: InstagramApiError = await response.json();
      console.error('Failed to reply to comment:', error);
      throw new Error(`Instagram API error: ${error.error.message}`);
    }

    return response.json();
  }

  /**
   * Send a direct message to an Instagram user
   * Note: Requires instagram_manage_messages permission and the user must have
   * messaged the business first, OR you need approved messaging permissions.
   * 
   * @param recipientId The Instagram-scoped user ID (IGSID)
   * @param message The message text
   */
  async sendDm(recipientId: string, message: string): Promise<{ id: string }> {
    const url = `${GRAPH_API_BASE}/me/messages`;
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        recipient: { id: recipientId },
        message: { text: message },
        access_token: this.accessToken,
      }),
    });

    if (!response.ok) {
      const error: InstagramApiError = await response.json();
      console.error('Failed to send DM:', error);
      
      // DM may fail if user hasn't messaged the business first
      if (error.error.code === 10900) {
        throw new Error('Cannot send DM: User must message the business first');
      }
      
      throw new Error(`Instagram API error: ${error.error.message}`);
    }

    return response.json();
  }

  /**
   * Get details about an Instagram post
   * @param postId The Instagram media ID
   */
  async getPostDetails(postId: string): Promise<{
    id: string;
    caption?: string;
    media_type: string;
    media_url?: string;
    thumbnail_url?: string;
    permalink: string;
  }> {
    const url = `${GRAPH_API_BASE}/${postId}`;
    const params = new URLSearchParams({
      fields: 'id,caption,media_type,media_url,thumbnail_url,permalink',
      access_token: this.accessToken,
    });

    const response = await fetch(`${url}?${params.toString()}`);

    if (!response.ok) {
      const error: InstagramApiError = await response.json();
      console.error('Failed to get post details:', error);
      throw new Error(`Instagram API error: ${error.error.message}`);
    }

    return response.json();
  }

  /**
   * Get the Instagram user ID from a comment
   * @param commentId The comment ID
   */
  async getCommentDetails(commentId: string): Promise<{
    id: string;
    text: string;
    username: string;
    from: {
      id: string;
      username: string;
    };
  }> {
    const url = `${GRAPH_API_BASE}/${commentId}`;
    const params = new URLSearchParams({
      fields: 'id,text,username,from',
      access_token: this.accessToken,
    });

    const response = await fetch(`${url}?${params.toString()}`);

    if (!response.ok) {
      const error: InstagramApiError = await response.json();
      console.error('Failed to get comment details:', error);
      throw new Error(`Instagram API error: ${error.error.message}`);
    }

    return response.json();
  }

  /**
   * Verify webhook signature from Facebook
   * @param signature The X-Hub-Signature-256 header value
   * @param body The raw request body
   * @param appSecret Your Facebook App Secret
   */
  static verifyWebhookSignature(
    signature: string,
    body: string,
    appSecret: string
  ): boolean {
    const crypto = require('crypto');
    const expectedSignature = 'sha256=' + 
      crypto.createHmac('sha256', appSecret)
        .update(body)
        .digest('hex');
    
    return signature === expectedSignature;
  }
}

/**
 * Exponential backoff retry for rate-limited requests
 */
export async function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries = 3,
  baseDelay = 1000
): Promise<T> {
  let lastError: Error;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;
      
      // Check if it's a rate limit error
      if (error instanceof Error && error.message.includes('rate limit')) {
        const delay = baseDelay * Math.pow(2, i);
        console.log(`Rate limited, retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      
      // For other errors, throw immediately
      throw error;
    }
  }
  
  throw lastError!;
}
