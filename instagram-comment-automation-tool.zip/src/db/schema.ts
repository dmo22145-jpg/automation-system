import { pgTable, text, timestamp, boolean, serial } from 'drizzle-orm/pg-core';

// Stores Instagram API credentials and configuration
export const config = pgTable('config', {
  id: serial('id').primaryKey(),
  instagramAccessToken: text('instagram_access_token'),
  instagramBusinessAccountId: text('instagram_business_account_id'),
  pageId: text('page_id'),
  webhookVerifyToken: text('webhook_verify_token'),
  facebookAppSecret: text('facebook_app_secret'),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Stores automation campaigns (post + keywords + reply messages)
export const campaigns = pgTable('campaigns', {
  id: serial('id').primaryKey(),
  postId: text('post_id').notNull(),
  postThumbnail: text('post_thumbnail'),
  postCaption: text('post_caption'),
  keywords: text('keywords').notNull(), // Comma-separated
  commentReply: text('comment_reply').notNull(),
  dmMessage: text('dm_message').notNull(),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Tracks processed comments to prevent duplicate processing
export const processedComments = pgTable('processed_comments', {
  id: serial('id').primaryKey(),
  commentId: text('comment_id').unique().notNull(),
  campaignId: serial('campaign_id').notNull().references(() => campaigns.id, { onDelete: 'cascade' }),
  commenterUsername: text('commenter_username'),
  processedAt: timestamp('processed_at').defaultNow().notNull(),
});

export type Config = typeof config.$inferSelect;
export type Campaign = typeof campaigns.$inferSelect;
export type ProcessedComment = typeof processedComments.$inferSelect;
