'use client';

import { useState, useEffect } from 'react';

export default function ConfigPanel() {
  const [config, setConfig] = useState({
    instagramAccessToken: '',
    instagramBusinessAccountId: '',
    pageId: '',
    webhookVerifyToken: '',
    facebookAppSecret: '',
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    fetchConfig();
  }, []);

  const fetchConfig = async () => {
    try {
      const response = await fetch('/api/config');
      const data = await response.json();
      setConfig({
        instagramAccessToken: data.instagramAccessToken || '',
        instagramBusinessAccountId: data.instagramBusinessAccountId || '',
        pageId: data.pageId || '',
        webhookVerifyToken: data.webhookVerifyToken || '',
        facebookAppSecret: data.facebookAppSecret || '',
      });
    } catch (error) {
      console.error('Error fetching config:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);

    try {
      const response = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });

      if (response.ok) {
        setMessage({ type: 'success', text: 'Configuration saved successfully!' });
      } else {
        setMessage({ type: 'error', text: 'Failed to save configuration' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Network error occurred' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="text-white">Loading configuration...</div>;
  }

  return (
    <div>
      <h2 className="text-2xl font-bold text-white mb-6">Instagram API Configuration</h2>
      
      <div className="bg-blue-500/20 border border-blue-400/50 rounded-lg p-4 mb-6">
        <h3 className="text-white font-semibold mb-2">📚 Setup Instructions</h3>
        <ol className="text-purple-100 text-sm space-y-2 ml-4 list-decimal">
          <li>Convert your Instagram account to Business or Creator</li>
          <li>Create a Facebook App at <a href="https://developers.facebook.com" target="_blank" className="text-blue-300 underline">developers.facebook.com</a></li>
          <li>Add the Instagram Graph API product</li>
          <li>Request permissions: <code className="bg-black/30 px-1 rounded">instagram_manage_comments</code> and <code className="bg-black/30 px-1 rounded">instagram_manage_messages</code></li>
          <li>Generate a long-lived User Access Token (60-day expiry)</li>
          <li>Configure webhook subscription for comments</li>
        </ol>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-white font-medium mb-2">
            Instagram Access Token *
          </label>
          <input
            type="password"
            value={config.instagramAccessToken}
            onChange={(e) => setConfig({ ...config, instagramAccessToken: e.target.value })}
            placeholder="Enter your Instagram User Access Token"
            className="w-full px-4 py-3 bg-white/10 border border-purple-400/30 rounded-lg text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
            required
          />
          <p className="text-xs text-purple-300 mt-1">
            Get this from Facebook Graph API Explorer or generate via app settings
          </p>
        </div>

        <div>
          <label className="block text-white font-medium mb-2">
            Instagram Business Account ID *
          </label>
          <input
            type="text"
            value={config.instagramBusinessAccountId}
            onChange={(e) => setConfig({ ...config, instagramBusinessAccountId: e.target.value })}
            placeholder="e.g., 17841405793187218"
            className="w-full px-4 py-3 bg-white/10 border border-purple-400/30 rounded-lg text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
            required
          />
          <p className="text-xs text-purple-300 mt-1">
            Find this in your Facebook Business Manager
          </p>
        </div>

        <div>
          <label className="block text-white font-medium mb-2">
            Facebook Page ID
          </label>
          <input
            type="text"
            value={config.pageId}
            onChange={(e) => setConfig({ ...config, pageId: e.target.value })}
            placeholder="e.g., 123456789012345"
            className="w-full px-4 py-3 bg-white/10 border border-purple-400/30 rounded-lg text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>

        <div>
          <label className="block text-white font-medium mb-2">
            Webhook Verify Token
          </label>
          <input
            type="password"
            value={config.webhookVerifyToken}
            onChange={(e) => setConfig({ ...config, webhookVerifyToken: e.target.value })}
            placeholder="Create a random string for webhook verification"
            className="w-full px-4 py-3 bg-white/10 border border-purple-400/30 rounded-lg text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <p className="text-xs text-purple-300 mt-1">
            This should match the verify token in your Facebook App webhook settings
          </p>
        </div>

        <div>
          <label className="block text-white font-medium mb-2">
            Facebook App Secret
          </label>
          <input
            type="password"
            value={config.facebookAppSecret}
            onChange={(e) => setConfig({ ...config, facebookAppSecret: e.target.value })}
            placeholder="Your Facebook App Secret"
            className="w-full px-4 py-3 bg-white/10 border border-purple-400/30 rounded-lg text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <p className="text-xs text-purple-300 mt-1">
            Used to verify webhook signatures for security
          </p>
        </div>

        {message && (
          <div className={`p-4 rounded-lg ${
            message.type === 'success' ? 'bg-green-500/20 border border-green-400/50' : 'bg-red-500/20 border border-red-400/50'
          }`}>
            <p className={message.type === 'success' ? 'text-green-200' : 'text-red-200'}>
              {message.text}
            </p>
          </div>
        )}

        <button
          type="submit"
          disabled={saving}
          className="w-full px-6 py-3 bg-purple-600 hover:bg-purple-700 disabled:bg-purple-800 text-white rounded-lg font-medium transition-colors shadow-lg"
        >
          {saving ? 'Saving...' : 'Save Configuration'}
        </button>
      </form>

      <div className="mt-8 bg-yellow-500/20 border border-yellow-400/50 rounded-lg p-4">
        <h3 className="text-white font-semibold mb-2">⚠️ Important Notes</h3>
        <ul className="text-purple-100 text-sm space-y-1 ml-4 list-disc">
          <li>Access tokens expire after 60 days - you'll need to refresh them regularly</li>
          <li>DMs only work if the user has messaged your business first (or with approved messaging permissions)</li>
          <li>Only use the official Instagram Graph API - no third-party libraries</li>
        </ul>
      </div>
    </div>
  );
}
