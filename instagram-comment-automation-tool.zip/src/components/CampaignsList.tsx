'use client';

import { useState, useEffect } from 'react';

interface Campaign {
  id: number;
  postId: string;
  postThumbnail: string | null;
  postCaption: string | null;
  keywords: string;
  commentReply: string;
  dmMessage: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

interface CampaignsListProps {
  refreshTrigger: number;
  onEdit: (campaign: Campaign) => void;
  onDeleted: () => void;
}

export default function CampaignsList({ refreshTrigger, onEdit, onDeleted }: CampaignsListProps) {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCampaigns();
  }, [refreshTrigger]);

  const fetchCampaigns = async () => {
    try {
      const response = await fetch('/api/campaigns');
      const data = await response.json();
      setCampaigns(data);
    } catch (error) {
      console.error('Error fetching campaigns:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleActive = async (id: number, isActive: boolean) => {
    try {
      await fetch(`/api/campaigns/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !isActive }),
      });
      fetchCampaigns();
    } catch (error) {
      console.error('Error toggling campaign:', error);
    }
  };

  const deleteCampaign = async (id: number) => {
    if (!confirm('Are you sure you want to delete this campaign?')) return;

    try {
      await fetch(`/api/campaigns/${id}`, { method: 'DELETE' });
      onDeleted();
    } catch (error) {
      console.error('Error deleting campaign:', error);
    }
  };

  if (loading) {
    return <div className="text-white">Loading campaigns...</div>;
  }

  if (campaigns.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-6xl mb-4">📭</div>
        <p className="text-white text-xl mb-2">No campaigns yet</p>
        <p className="text-purple-300">Create your first campaign to start automating!</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {campaigns.map((campaign) => (
        <div
          key={campaign.id}
          className="bg-white/5 border border-purple-400/30 rounded-xl p-6 hover:bg-white/10 transition-all"
        >
          <div className="flex gap-6">
            {/* Post Thumbnail */}
            {campaign.postThumbnail && (
              <div className="flex-shrink-0">
                <img
                  src={campaign.postThumbnail}
                  alt="Post thumbnail"
                  className="w-24 h-24 object-cover rounded-lg"
                />
              </div>
            )}

            {/* Campaign Details */}
            <div className="flex-1">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-white font-semibold text-lg">
                      Post ID: {campaign.postId}
                    </h3>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        campaign.isActive
                          ? 'bg-green-500/20 text-green-300 border border-green-400/50'
                          : 'bg-gray-500/20 text-gray-300 border border-gray-400/50'
                      }`}
                    >
                      {campaign.isActive ? '✓ Active' : '○ Inactive'}
                    </span>
                  </div>
                  {campaign.postCaption && (
                    <p className="text-purple-200 text-sm line-clamp-2">
                      {campaign.postCaption}
                    </p>
                  )}
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <button
                    onClick={() => toggleActive(campaign.id, campaign.isActive)}
                    className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors"
                    title={campaign.isActive ? 'Deactivate' : 'Activate'}
                  >
                    {campaign.isActive ? '⏸' : '▶'}
                  </button>
                  <button
                    onClick={() => onEdit(campaign)}
                    className="px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm transition-colors"
                    title="Edit"
                  >
                    ✏️
                  </button>
                  <button
                    onClick={() => deleteCampaign(campaign.id)}
                    className="px-3 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-sm transition-colors"
                    title="Delete"
                  >
                    🗑️
                  </button>
                </div>
              </div>

              {/* Keywords */}
              <div className="mb-3">
                <span className="text-purple-400 text-sm font-medium">Keywords: </span>
                <div className="inline-flex flex-wrap gap-2 mt-1">
                  {campaign.keywords.split(',').map((keyword, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-1 bg-purple-500/20 text-purple-200 rounded text-sm border border-purple-400/30"
                    >
                      {keyword.trim()}
                    </span>
                  ))}
                </div>
              </div>

              {/* Comment Reply Preview */}
              <div className="mb-2">
                <span className="text-purple-400 text-sm font-medium">Comment Reply: </span>
                <span className="text-purple-200 text-sm">
                  {campaign.commentReply.substring(0, 100)}
                  {campaign.commentReply.length > 100 ? '...' : ''}
                </span>
              </div>

              {/* DM Preview */}
              <div>
                <span className="text-purple-400 text-sm font-medium">DM Message: </span>
                <span className="text-purple-200 text-sm">
                  {campaign.dmMessage.substring(0, 100)}
                  {campaign.dmMessage.length > 100 ? '...' : ''}
                </span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
