'use client';

import { useState, useEffect } from 'react';

interface CampaignFormProps {
  campaign?: any;
  onSaved: () => void;
  onCancel: () => void;
}

export default function CampaignForm({ campaign, onSaved, onCancel }: CampaignFormProps) {
  const [formData, setFormData] = useState({
    postId: '',
    keywords: '',
    commentReply: '',
    dmMessage: '',
    isActive: true,
  });
  const [postPreview, setPostPreview] = useState<any>(null);
  const [loadingPreview, setLoadingPreview] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (campaign) {
      setFormData({
        postId: campaign.postId || '',
        keywords: campaign.keywords || '',
        commentReply: campaign.commentReply || '',
        dmMessage: campaign.dmMessage || '',
        isActive: campaign.isActive ?? true,
      });
    }
  }, [campaign]);

  const fetchPostPreview = async (postId: string) => {
    if (!postId.trim()) {
      setPostPreview(null);
      return;
    }

    setLoadingPreview(true);
    setError(null);

    try {
      const response = await fetch(`/api/post-preview?postId=${encodeURIComponent(postId)}`);
      if (response.ok) {
        const data = await response.json();
        setPostPreview(data);
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Failed to fetch post details');
        setPostPreview(null);
      }
    } catch (err) {
      setError('Network error while fetching post details');
      setPostPreview(null);
    } finally {
      setLoadingPreview(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);

    try {
      const url = campaign ? `/api/campaigns/${campaign.id}` : '/api/campaigns';
      const method = campaign ? 'PATCH' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        onSaved();
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Failed to save campaign');
      }
    } catch (err) {
      setError('Network error occurred');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">
          {campaign ? 'Edit Campaign' : 'Create New Campaign'}
        </h2>
        <button
          onClick={onCancel}
          className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors"
        >
          ← Back
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Post ID */}
        <div>
          <label className="block text-white font-medium mb-2">
            Instagram Post ID *
          </label>
          <input
            type="text"
            value={formData.postId}
            onChange={(e) => setFormData({ ...formData, postId: e.target.value })}
            onBlur={(e) => fetchPostPreview(e.target.value)}
            placeholder="e.g., 17895695668004550"
            className="w-full px-4 py-3 bg-white/10 border border-purple-400/30 rounded-lg text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
            required
            disabled={!!campaign}
          />
          <p className="text-xs text-purple-300 mt-1">
            Get this from Instagram Graph API Explorer or your post URL
          </p>
        </div>

        {/* Post Preview */}
        {loadingPreview && (
          <div className="bg-white/5 border border-purple-400/30 rounded-lg p-4">
            <p className="text-purple-200">Loading post preview...</p>
          </div>
        )}

        {postPreview && (
          <div className="bg-white/5 border border-purple-400/30 rounded-lg p-4">
            <div className="flex gap-4">
              {postPreview.thumbnail && (
                <img
                  src={postPreview.thumbnail}
                  alt="Post preview"
                  className="w-32 h-32 object-cover rounded-lg"
                />
              )}
              <div className="flex-1">
                <p className="text-white font-medium mb-2">✓ Post Found</p>
                {postPreview.caption && (
                  <p className="text-purple-200 text-sm line-clamp-3">
                    {postPreview.caption}
                  </p>
                )}
                <a
                  href={postPreview.permalink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 text-sm hover:underline mt-2 inline-block"
                >
                  View on Instagram →
                </a>
              </div>
            </div>
          </div>
        )}

        {/* Keywords */}
        <div>
          <label className="block text-white font-medium mb-2">
            Trigger Keywords *
          </label>
          <input
            type="text"
            value={formData.keywords}
            onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
            placeholder="e.g., free, download, link (comma-separated)"
            className="w-full px-4 py-3 bg-white/10 border border-purple-400/30 rounded-lg text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
            required
          />
          <p className="text-xs text-purple-300 mt-1">
            Enter keywords separated by commas. Matching is case-insensitive and partial.
          </p>
        </div>

        {/* Comment Reply */}
        <div>
          <label className="block text-white font-medium mb-2">
            Comment Reply Message *
          </label>
          <textarea
            value={formData.commentReply}
            onChange={(e) => setFormData({ ...formData, commentReply: e.target.value })}
            placeholder="This will be posted as a public reply to the comment..."
            rows={4}
            className="w-full px-4 py-3 bg-white/10 border border-purple-400/30 rounded-lg text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
            required
          />
          <p className="text-xs text-purple-300 mt-1">
            Character count: {formData.commentReply.length}
          </p>
        </div>

        {/* DM Message */}
        <div>
          <label className="block text-white font-medium mb-2">
            Direct Message (DM) *
          </label>
          <textarea
            value={formData.dmMessage}
            onChange={(e) => setFormData({ ...formData, dmMessage: e.target.value })}
            placeholder="This will be sent as a private DM to the commenter..."
            rows={4}
            className="w-full px-4 py-3 bg-white/10 border border-purple-400/30 rounded-lg text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
            required
          />
          <p className="text-xs text-purple-300 mt-1">
            Character count: {formData.dmMessage.length}
          </p>
          <div className="bg-yellow-500/20 border border-yellow-400/50 rounded-lg p-3 mt-2">
            <p className="text-yellow-200 text-xs">
              ⚠️ Note: DMs will only work if the user has messaged your business first, or if you have approved messaging permissions from Facebook.
            </p>
          </div>
        </div>

        {/* Active Toggle */}
        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            id="isActive"
            checked={formData.isActive}
            onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
            className="w-5 h-5 rounded bg-white/10 border-purple-400/30 text-purple-600 focus:ring-2 focus:ring-purple-500"
          />
          <label htmlFor="isActive" className="text-white font-medium">
            Campaign is active
          </label>
        </div>

        {error && (
          <div className="bg-red-500/20 border border-red-400/50 rounded-lg p-4">
            <p className="text-red-200">{error}</p>
          </div>
        )}

        {/* Submit Buttons */}
        <div className="flex gap-4">
          <button
            type="submit"
            disabled={saving}
            className="flex-1 px-6 py-3 bg-purple-600 hover:bg-purple-700 disabled:bg-purple-800 text-white rounded-lg font-medium transition-colors shadow-lg"
          >
            {saving ? 'Saving...' : campaign ? 'Update Campaign' : 'Create Campaign'}
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-lg font-medium transition-colors"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}
